from setuptools import setup, find_packages

# Use 'pip install build' in this folder
# Go to packages folder and use 'python -m build'
setup(
    name='titanic_ml_project',
    version='0.1',
    description='ML project around Titanic dataset',
    author='Luis Cerdeño Mota',
    author_email='luiscerdenomota@gmail.com',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'numpy',
        'scikit-learn',
        'mlflow'
    ],
    entry_points={
        'console_scripts': [
            'titanic_ml_project=src.train_eval:main'
        ]
    }
)
